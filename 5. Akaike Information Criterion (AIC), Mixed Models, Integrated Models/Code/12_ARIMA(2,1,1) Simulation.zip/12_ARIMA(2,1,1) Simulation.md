
# ARIMA(2,1,1) Simulation


```R
# parameters
phi=c(.7, .2)
beta=0.5
sigma=3
m=10000
```


```R
set.seed(5)
Simulated.Arima=arima.sim(n=m,list(order = c(2,1,1), ar = phi, ma=beta))
```


```R
plot(Simulated.Arima, ylab=' ',main='Simulated time series from ARIMA(2,1,1) process', col='blue', lwd=2)
```


![png](output_3_0.png)



```R
acf(Simulated.Arima)
```


![png](output_4_0.png)



```R
Diff.Simulated.Arima=diff(Simulated.Arima)
```


```R
plot(Diff.Simulated.Arima)
```


![png](output_6_0.png)



```R
acf(Diff.Simulated.Arima)
```


![png](output_7_0.png)



```R
pacf(Diff.Simulated.Arima)
```


![png](output_8_0.png)



```R
library(astsa)
sarima(Simulated.Arima,2,1,1,0,0,0)
```

    initial  value 1.092704 
    iter   2 value 0.655083
    iter   3 value 0.576329
    iter   4 value 0.250793
    iter   5 value 0.124855
    iter   6 value 0.033738
    iter   7 value 0.013225
    iter   8 value 0.012554
    iter   9 value 0.012517
    iter  10 value 0.012292
    iter  11 value 0.012267
    iter  12 value 0.012258
    iter  13 value 0.012170
    iter  14 value 0.012069
    iter  15 value 0.011860
    iter  16 value 0.011703
    iter  17 value 0.011609
    iter  18 value 0.011601
    iter  19 value 0.011601
    iter  20 value 0.011601
    iter  20 value 0.011601
    iter  20 value 0.011601
    final  value 0.011601 
    converged
    initial  value 0.011653 
    iter   2 value 0.011653
    iter   3 value 0.011653
    iter   3 value 0.011653
    iter   3 value 0.011653
    final  value 0.011653 
    converged



    $fit
    
    Call:
    stats::arima(x = xdata, order = c(p, d, q), seasonal = list(order = c(P, D, 
        Q), period = S), xreg = constant, optim.control = list(trace = trc, REPORT = 1, 
        reltol = tol))
    
    Coefficients:
             ar1    ar2     ma1  constant
          0.6876  0.204  0.5002    0.0280
    s.e.  0.0334  0.032  0.0301    0.1398
    
    sigma^2 estimated as 1.023:  log likelihood = -14305.92,  aic = 28621.83
    
    $degrees_of_freedom
    [1] 9997
    
    $ttable
             Estimate     SE t.value p.value
    ar1        0.6876 0.0334 20.5786  0.0000
    ar2        0.2040 0.0320  6.3817  0.0000
    ma1        0.5002 0.0301 16.6139  0.0000
    constant   0.0280 0.1398  0.2001  0.8414
    
    $AIC
    [1] 1.02388
    
    $AICc
    [1] 1.024081
    
    $BIC
    [1] 0.02676403




![png](output_9_2.png)



```R
library(forecast)
auto.arima(Simulated.Arima)
```

    
    Attaching package: ‘forecast’
    
    The following object is masked from ‘package:astsa’:
    
        gas
    



    Series: Simulated.Arima 
    ARIMA(3,2,1)                    
    
    Coefficients:
              ar1     ar2      ar3     ma1
          -0.4718  0.0003  -0.0672  0.7032
    s.e.   0.0748  0.0205   0.0178  0.0738
    
    sigma^2 estimated as 1.067:  log likelihood=-14508.72
    AIC=29027.44   AICc=29027.44   BIC=29063.49



```R
fit1<-arima(Diff.Simulated.Arima, order=c(4,0,0))
```


```R
fit1
```


    
    Call:
    arima(x = Diff.Simulated.Arima, order = c(4, 0, 0))
    
    Coefficients:
             ar1      ar2     ar3      ar4  intercept
          1.1862  -0.3761  0.1733  -0.0581     0.0280
    s.e.  0.0100   0.0154  0.0154   0.0100     0.1353
    
    sigma^2 estimated as 1.025:  log likelihood = -14313.1,  aic = 28638.2



```R
fit2<-arima(Diff.Simulated.Arima, order=c(2,0,1))
```


```R
fit2
```


    
    Call:
    arima(x = Diff.Simulated.Arima, order = c(2, 0, 1))
    
    Coefficients:
             ar1    ar2     ma1  intercept
          0.6876  0.204  0.5002     0.0280
    s.e.  0.0334  0.032  0.0301     0.1398
    
    sigma^2 estimated as 1.023:  log likelihood = -14305.92,  aic = 28621.83



```R
fit3<-arima(Simulated.Arima, order=c(2,1,1))
```


```R
fit3
```


    
    Call:
    arima(x = Simulated.Arima, order = c(2, 1, 1))
    
    Coefficients:
             ar1     ar2     ma1
          0.6876  0.2039  0.5001
    s.e.  0.0334  0.0320  0.0301
    
    sigma^2 estimated as 1.023:  log likelihood = -14305.93,  aic = 28619.85

