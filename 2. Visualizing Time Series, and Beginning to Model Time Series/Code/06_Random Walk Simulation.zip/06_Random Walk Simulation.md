
# Random Walk Simulation


```R
x = NULL
x[1] = 0
for(i in 2:1000){
    x[i] = x[i-1] + rnorm(1)
}

print(x[1:10])

# Convertimos a ts
random_walk = ts(x)
```

     [1] 0.0000000 0.9034452 2.1262212 1.4833841 3.5007714 2.6626792 2.9371726
     [8] 2.6264726 3.5938082 4.6674391



```R
plot(random_walk, 
     main='A random walk',
     ylab=' ',
     xlab='Days',
     col='blue',
     lwd=2)
```


![png](output_2_0.png)


Esta serie no es estacionaria, por lo que **no tendría sentido** representar ACF. No obstante, hagámoslo:


```R
acf(random_walk)
```


![png](output_4_0.png)


Vemos que los lags están correladísimos (tiene mucho sentido).

### Serie en diferencias


```R
plot(diff(random_walk))
```


![png](output_7_0.png)


Vemos que es un proceso bastante aleatorio. Vamos a ver ACF:


```R
acf(diff(random_walk))
```


![png](output_9_0.png)

