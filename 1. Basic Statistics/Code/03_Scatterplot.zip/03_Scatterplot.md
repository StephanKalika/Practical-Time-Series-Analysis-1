
# Scatterplot


```R
# Vamos a generar un dataset aleatorio
set.seed(2016)  # There is a typo in the video (set.seed=2016)
```

Generamos datos aleatorios:


```R
Test_1_scores=round(rnorm(50, 78, 10))
```


```R
Test_2_scores=round(rnorm(50, 78, 14))
```


```R
Test_1_scores # Data won't be the same with the data generated in the video lecture since there was a typo in set.seed. 
```


<ol class=list-inline>
	<li>69</li>
	<li>88</li>
	<li>77</li>
	<li>81</li>
	<li>50</li>
	<li>75</li>
	<li>70</li>
	<li>71</li>
	<li>82</li>
	<li>80</li>
	<li>74</li>
	<li>75</li>
	<li>91</li>
	<li>69</li>
	<li>94</li>
	<li>81</li>
	<li>69</li>
	<li>88</li>
	<li>71</li>
	<li>71</li>
	<li>74</li>
	<li>71</li>
	<li>75</li>
	<li>84</li>
	<li>80</li>
	<li>68</li>
	<li>72</li>
	<li>91</li>
	<li>89</li>
	<li>67</li>
	<li>68</li>
	<li>77</li>
	<li>90</li>
	<li>63</li>
	<li>79</li>
	<li>92</li>
	<li>70</li>
	<li>70</li>
	<li>73</li>
	<li>63</li>
	<li>77</li>
	<li>83</li>
	<li>75</li>
	<li>72</li>
	<li>87</li>
	<li>75</li>
	<li>65</li>
	<li>100</li>
	<li>86</li>
	<li>61</li>
</ol>




```R
Test_2_scores # Data won't be the same with the data generated in the video lecture since there was a typo in set.seed. 
```


<ol class=list-inline>
	<li>76</li>
	<li>66</li>
	<li>43</li>
	<li>62</li>
	<li>80</li>
	<li>55</li>
	<li>101</li>
	<li>61</li>
	<li>73</li>
	<li>72</li>
	<li>88</li>
	<li>87</li>
	<li>70</li>
	<li>70</li>
	<li>85</li>
	<li>97</li>
	<li>74</li>
	<li>62</li>
	<li>72</li>
	<li>90</li>
	<li>91</li>
	<li>83</li>
	<li>51</li>
	<li>78</li>
	<li>77</li>
	<li>89</li>
	<li>81</li>
	<li>91</li>
	<li>78</li>
	<li>73</li>
	<li>86</li>
	<li>85</li>
	<li>86</li>
	<li>67</li>
	<li>57</li>
	<li>106</li>
	<li>70</li>
	<li>87</li>
	<li>74</li>
	<li>81</li>
	<li>97</li>
	<li>86</li>
	<li>61</li>
	<li>88</li>
	<li>73</li>
	<li>70</li>
	<li>80</li>
	<li>74</li>
	<li>46</li>
	<li>95</li>
</ol>




```R
# Scatterplot
plot(Test_2_scores~Test_1_scores)
```


![png](output_7_0.png)



```R
# Etiquetas
plot(Test_2_scores~Test_1_scores, main='Test scores for two exams (50 students)', xlab='Test_1_scores', ylab='Test 2 scores')
```


![png](output_8_0.png)



```R
# Color
plot(Test_2_scores~Test_1_scores, main='Test scores for two exams (50 students)', xlab='Test_1_scores', ylab='Test 2 scores', col='blue')
```


![png](output_9_0.png)



```R

```
