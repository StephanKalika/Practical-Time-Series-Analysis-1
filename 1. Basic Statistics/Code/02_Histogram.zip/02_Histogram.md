
# Histogram


```R
# Creamos un dataset

small.size.dataset=c(91,49,76,112,97,42,70, 100, 8, 112, 95, 90, 78, 62, 56, 94, 65, 58, 109, 70, 109, 91, 71, 76, 68, 62, 134, 57, 83, 66)
```


```R
hist(small.size.dataset)
```


![png](output_2_0.png)



```R
# Etiquetas
hist(small.size.dataset, xlab='My data points')
```


![png](output_3_0.png)



```R
# Título
hist(small.size.dataset, xlab='My data points', main='Histogram of my data')
```


![png](output_4_0.png)



```R
# Porcentaje (freq = FALSE)
hist(small.size.dataset, xlab='My data points', main='Histogram of my data', freq=F)
```


![png](output_5_0.png)



```R
# Color
hist(small.size.dataset, xlab='My data points', main='Histogram of my data', freq=F, col='green')
```


![png](output_6_0.png)



```R
# kde
hist(small.size.dataset, xlab='My data points', main='Histogram of my data', freq=F, col='green')
lines(density(small.size.dataset))
```


![png](output_7_0.png)



```R
# Line width
hist(small.size.dataset, xlab='My data points', main='Histogram of my data', freq=F, col='green')
lines(density(small.size.dataset), col='red', lwd=5)
```


![png](output_8_0.png)



```R
# Breakpoints
hist(small.size.dataset, 
     xlab='My data points', 
     main='Histogram of my data', 
     freq=F, 
     col='green', 
     breaks=10)
```


![png](output_9_0.png)



```R
hist(small.size.dataset, xlab='My data points', main='Histogram of my data', freq=F, col='green', breaks=10)
lines(density(small.size.dataset), col='red', lwd=5)
```


![png](output_10_0.png)

