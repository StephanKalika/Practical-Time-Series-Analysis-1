
# ACF

Creamos un proceso puramente aleatorio:


```R
purely_random_process = ts(rnorm(100))
```


```R
print(purely_random_process)
```

    Time Series:
    Start = 1 
    End = 100 
    Frequency = 1 
      [1] -0.05848593  0.51209086  0.22786692 -0.27579171 -0.90821087 -0.40842846
      [7] -0.31564311 -0.04352122 -0.32090267 -0.49131597 -1.20460295 -0.14217865
     [13] -1.23366734 -0.34736607 -0.09383332  0.24654432  0.32858164  2.22185465
     [19]  1.89849291 -0.86074243 -0.80249625  0.04845093  1.32711003 -1.81809329
     [25] -2.57695500  0.34558394 -0.67051306 -1.16106461 -1.76527349  2.18533337
     [31] -0.88588960 -1.23264938  0.71405140 -0.80234876  0.88014877 -0.05020845
     [37] -0.07429617 -1.95178369 -0.95634487 -0.31546578 -1.10540350  0.93883550
     [43] -1.53402144 -0.48635998  0.79174354 -0.50783620 -0.17694708  0.76212334
     [49]  1.04850676  0.41414092 -0.21115349 -0.08974324  0.94294286 -1.23767281
     [55] -0.28151515 -1.54707222  1.16949467 -0.96537699  0.61840769 -0.54818284
     [61]  0.17450915 -0.63276295 -0.72710838  0.09186997 -1.24954205  0.57330890
     [67] -0.26219409 -1.11748397 -0.66243300 -1.55833992 -1.47706589  0.65615268
     [73] -1.18318661  0.85468908 -2.06698041 -1.26759328  0.20119103  2.46490354
     [79] -0.64459409  0.69598381 -0.53718913 -0.27207330 -0.11154171  0.91204594
     [85]  0.83031648 -1.36319815  0.03261013  0.41694638 -0.20920751  1.19787218
     [91] -0.86659545  0.94015996 -0.52865677 -0.00498575  0.10752086 -0.74241469
     [97]  1.51592088 -0.91567700 -0.81514163  1.16481691


Obtenemos los autocovariance coefficients y los ploteamos:


```R
(acf(purely_random_process, type='covariance'))
```


    
    Autocovariances of series ‘purely_random_process’, by lag
    
           0        1        2        3        4        5        6        7 
     0.95050 -0.09813 -0.00981  0.00764  0.09562  0.02620 -0.13401  0.05260 
           8        9       10       11       12       13       14       15 
    -0.10828 -0.14132 -0.06614 -0.03124  0.13020 -0.03974  0.00349  0.06259 
          16       17       18       19       20 
     0.02597  0.03465  0.00581  0.04457 -0.14440 



![png](output_5_1.png)


Ahora dibujamos el correlograma:


```R
acf(purely_random_process,
    main='Correlogram of a purely random process')
```


![png](output_7_0.png)


Observamos lo siguiente:
* La barra en 0 siempre es 1, porque estamos pintando la correlación de cada lag con el lag 0.
* Después no tengo demasiada correlación entre los diferentes lags, lo que tiene sentido porque es un proceso puramente aleatorio.
* Las líneas representan el nivel de significación.
* Tenemos hasta el lag 20, pero podemos hacerlo hasta el que queramos.

Podemos decir que este correlograma se corresponde con una serie que es ruido. Aunque alguna barrita se saliera un poquito, seguiría siéndolo.
