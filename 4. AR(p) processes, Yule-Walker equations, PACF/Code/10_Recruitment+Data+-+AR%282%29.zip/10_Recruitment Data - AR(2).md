
# Modeling recruitment time series from 'astsa' package as an AR process

Vamos a intentar fittear un AR a los datos y estimar sus parámetros.


```R
library(astsa)
my.data=rec

# Plot rec 
plot(rec, main='Recruitment time series', col='blue', lwd=3)
```


![png](output_2_0.png)



```R
# subtract mean to get a time series with mean zero
ar.process=my.data-mean(my.data)

# ACF and PACF of the process
par(mfrow=c(2,1))
acf(ar.process, main='Recruitment', col='red', lwd=3)
pacf(ar.process, main='Recruitment', col='green', lwd=3)
```


![png](output_3_0.png)


Al ver la PACF vemos que podemos modelarlo con un $AR(2)$.


```R
# order
p=2

# sample autocorreleation function r
r=NULL
r[1:p]=acf(ar.process, plot=F)$acf[2:(p+1)]
cat('r=',r,'\n')
```

    r= 0.9218042 0.7829182 



```R
# matrix R
R=matrix(1,p,p) # matrix of dimension 2 by 2, with entries all 1's.

# define non-diagonal entries of R
for(i in 1:p){
	for(j in 1:p){
		if(i!=j)
			R[i,j]=r[abs(i-j)]
		}
	}
R
```


<table>
<tbody>
	<tr><td>1.0000000</td><td>0.9218042</td></tr>
	<tr><td>0.9218042</td><td>1.0000000</td></tr>
</tbody>
</table>




```R
# b-column vector on the right
b=NULL
b=matrix(r,p,1)# b- column vector with no entries
b
```


<table>
<tbody>
	<tr><td>0.9218042</td></tr>
	<tr><td>0.7829182</td></tr>
</tbody>
</table>




```R
# solve(R,b) solves Rx=b, and gives x=R^(-1)b vector
phi.hat=NULL
phi.hat=solve(R,b)[,1]
phi.hat
```


<ol class=list-inline>
	<li>1.33158738866791</li>
	<li>-0.444544697634473</li>
</ol>




```R
#variance estimation using Yule-Walker Estimator
c0=acf(ar.process, type='covariance', plot=F)$acf[1]
c0
```


780.990977796933



```R
var.hat=c0*(1-sum(phi.hat*r))
var.hat
```


94.1713101077287



```R
# constant term in the model
phi0.hat=mean(my.data)*(1-sum(phi.hat))
phi0.hat
```


7.03303626708593



```R
cat("Constant:", phi0.hat," Coefficients:", phi.hat, " and Variance:", var.hat, '\n')
```

    Constant: 7.033036  Coefficients: 1.331587 -0.4445447  and Variance: 94.17131 

