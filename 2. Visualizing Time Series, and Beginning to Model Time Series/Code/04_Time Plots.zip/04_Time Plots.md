
# Time plots


```R
require(astsa)
```

    Loading required package: astsa



```R
help(astsa)
help(jj)
```

## Johnson&Johnson quarterly EPS

Representemos el EPS de J&J:


```R
plot(jj,
     type='o',  # para dibujar los puntos
     main='Johnson&Johnson quarterly EPS',
     ylab='Earnings',
     xlab='Years')
```


![png](output_5_0.png)


El primer paso en análisis de time series es hacer un time plot, ya que sólo echando un vistazo podemos hacernos una idea de lo que hay.

Vemos que hay una tendencia, y también estacionalidad (fluctuaciones). Al principio no hay muchas variaciones, pero luego se van acentuando. Esto lo veremos, pero podemos adelantar que el hecho de tener diferentes variaciones en diferentes partes de la serie viola el **principio de esacionariedad**.

## Pneumonia and influenza deaths in the U.S.


```R
help(flu)
```


```R
plot(flu,
     main='Monthly Pneumonia and Influenza Deaths in US',
     ylab='Number of Deaths per 10,000 people',
     xlab='Months')
```


![png](output_9_0.png)


Vemos que hay estacionalidad (los picos se repiten). Vemos que puede haber una tendencia descendente pero es difícil de ver.

## Land-ocean temperature deviations


```R
help(globtemp)
```

Indica desviaciones sobre la media de temperaturas.


```R
plot(globtemp,
     type='o',
     main='Global mean land-ocean deviations from average temperature of 1951-1980',
     ylab='Temperature deviations',
     xlab='Years')
```


![png](output_14_0.png)


La primera impresión es que hay una tendencia creciente. También hay algo de estacionalidad.

## Land (only) temperature deviations


```R
help(globtempl)
```


```R
plot(globtempl)
```


![png](output_18_0.png)


## Variable Star


```R
help(star)
```


```R
plot(star,
     main='The magnitude of a star taken at midnight for 600 consecutive days',
     ylab='Magnitude', 
     xlab='Days')
```


![png](output_21_0.png)


La estacionalidad es clara.
