
# Johnson & Johnson quarterly earnings per share


```R
# Time plot for Johnson&Johnson
plot(JohnsonJohnson, main='Johnson&Johnosn earnings per share', col='blue', lwd=3)
```


![png](output_1_0.png)


Vemos que hay una tendencia clara por lo que la serie no es estacionaria. Por tanto, no podemos intentar fitter un AR estacionario. Tenemos que transformar la serie en estacionaria.

Log-return:

$log(\frac{X_{t}}{X_{t-1}})$


```R
# log-return of Johnson&Johnson
jj.log.return=diff(log(JohnsonJohnson))
jj.log.return.mean.zero=jj.log.return-mean(jj.log.return)
```

Recordemos que para estimar con Yule-Walker la media tiene que ser 0.


```R
# Plots for log-returns
par(mfrow=c(3,1))
plot(jj.log.return.mean.zero, main='Log-return (mean zero) of Johnson&Johnosn earnings per share')
acf(jj.log.return.mean.zero, main='ACF')
pacf(jj.log.return.mean.zero, main='PACF')
```


![png](output_6_0.png)



```R
# Order
p=4
```


```R
# sample autocorreleation function r
r=NULL
r[1:p]=acf(jj.log.return.mean.zero, plot=F)$acf[2:(p+1)]
r
```


<ol class=list-inline>
	<li>-0.506817600046513</li>
	<li>0.0671008385072088</li>
	<li>-0.402836036322625</li>
	<li>0.731447804138696</li>
</ol>




```R
# matrix R
R=matrix(1,p,p) # matrix of dimension 4 by 4, with entries all 1's.

# define non-diagonal entires of R
for(i in 1:p){
	for(j in 1:p){
		if(i!=j)
			R[i,j]=r[abs(i-j)]
		}
	}
R
```


<table>
<tbody>
	<tr><td> 1.00000000</td><td>-0.50681760</td><td> 0.06710084</td><td>-0.40283604</td></tr>
	<tr><td>-0.50681760</td><td> 1.00000000</td><td>-0.50681760</td><td> 0.06710084</td></tr>
	<tr><td> 0.06710084</td><td>-0.50681760</td><td> 1.00000000</td><td>-0.50681760</td></tr>
	<tr><td>-0.40283604</td><td> 0.06710084</td><td>-0.50681760</td><td> 1.00000000</td></tr>
</tbody>
</table>




```R
# b-column vector on the right
b=matrix(r,p,1)# b- column vector with no entries
b
```


<table>
<tbody>
	<tr><td>-0.50681760</td></tr>
	<tr><td> 0.06710084</td></tr>
	<tr><td>-0.40283604</td></tr>
	<tr><td> 0.73144780</td></tr>
</tbody>
</table>




```R
phi.hat=solve(R,b)[,1]
phi.hat
```


<ol class=list-inline>
	<li>-0.629349240726127</li>
	<li>-0.51715263230406</li>
	<li>-0.488337379525746</li>
	<li>0.2651266471015</li>
</ol>




```R
# Variance estimation using Yule-Walker Estimator
c0=acf(jj.log.return.mean.zero, type='covariance', plot=F)$acf[1]
c0
var.hat=c0*(1-sum(phi.hat*r))
var.hat
```


0.0436569182631469



0.0141924234234426



```R
# Constant term in the model
phi0.hat=mean(jj.log.return)*(1-sum(phi.hat))
phi0.hat
```


0.0797810030728414



```R
cat("Constant:", phi0.hat," Coefficients:", phi.hat, " and Variance:", var.hat, '\n')
```

    Constant: 0.079781  Coeffcinets: -0.6293492 -0.5171526 -0.4883374 0.2651266  and Variance: 0.01419242 

