
## The following time series is taken from Time Series Data Library (TSDL)
## TSDL  was created by Rob Hyndman
## Professor of Statistics at Monash University, Australia.
## ==============================================================

## ====== Daily total female birth in California, 1959 =======

## Data is exported as csv file to the wroking directory
## Link: https://datamarket.com/data/list/?q=cat:fwy%20provider:tsdl


```R
library(astsa)

# read data to R variable
birth.data<-read.csv("daily-total-female-births-in-cal.csv")

# pull out number of births column
number_of_births<-birth.data$Daily.total.female.births.in.California..1959

# use date format for dates
birth.data$Date <- as.Date(birth.data$Date, "%m/%d/%Y")


```


```R
plot.ts(number_of_births,main='Daily total female births in california, 1959', ylab = 'Number of births')
```


![png](output_2_0.png)


Tenemos una tendencia, por lo que el proceso no es estacionario.


```R
# Test for correlation
Box.test(number_of_births, lag = log(length(number_of_births)))
```


    
    	Box-Pierce test
    
    data:  number_of_births
    X-squared = 36.391, df = 5.8999, p-value = 2.088e-06



Hay autocorrelaciones.


```R
# Plot the differenced data
plot.ts(diff(number_of_births), main='Differenced series', ylab = '')
```


![png](output_6_0.png)


Ahora parece estacionaria.


```R
# Test for correlation in the differenced data
Box.test(diff(number_of_births), lag = log(length(diff(number_of_births))))
```


    
    	Box-Pierce test
    
    data:  diff(number_of_births)
    X-squared = 78.094, df = 5.8972, p-value = 7.661e-15



Hay autocorrelaciones.


```R
# acf and pacf of the differenced data

acf(diff(number_of_births), main='ACF of differenced data', 50)
pacf(diff(number_of_births), main='PACF of differenced data', 50)
```


![png](output_10_0.png)



![png](output_10_1.png)


* En ACF vemos que tenemos dos picos significativos. Esto nos sugiere que el MA puede ser de orden 2.
* En PACF tenemos un montón de picos significativos hasta el lag 7.

Vamos a probar varios modelos:


```R
# Fit various ARIMA models


model1<-arima(number_of_births, order=c(0,1,1))
SSE1<-sum(model1$residuals^2)
print(model1.test<-Box.test(model1$residuals, lag = log(length(model1$residuals))))

model2<-arima(number_of_births, order=c(0,1,2))
SSE2<-sum(model2$residuals^2)
print(model2.test<-Box.test(model2$residuals, lag = log(length(model2$residuals))))

model3<-arima(number_of_births, order=c(7,1,1))
SSE3<-sum(model3$residuals^2)
print(model3.test<-Box.test(model3$residuals, lag = log(length(model3$residuals))))

model4<-arima(number_of_births, order=c(7,1,2))
SSE4<-sum(model4$residuals^2)
print(model4.test<-Box.test(model4$residuals, lag = log(length(model4$residuals))))

df<-data.frame(row.names=c('AIC', 'SSE', 'p-value'), c(model1$aic, SSE1, model1.test$p.value), 
               c(model2$aic, SSE2, model2.test$p.value), c(model3$aic, SSE3, model3.test$p.value),
               c(model4$aic, SSE4, model4.test$p.value))
colnames(df)<-c('Arima(0,1,1)','Arima(0,1,2)', 'Arima(7,1,1)', 'Arima(7,1,2)')



format(df, scientific=FALSE)
```

    
    	Box-Pierce test
    
    data:  model1$residuals
    X-squared = 4.9846, df = 5.8999, p-value = 0.5334
    
    
    	Box-Pierce test
    
    data:  model2$residuals
    X-squared = 0.95455, df = 5.8999, p-value = 0.9859
    
    
    	Box-Pierce test
    
    data:  model3$residuals
    X-squared = 0.073557, df = 5.8999, p-value = 1
    
    
    	Box-Pierce test
    
    data:  model4$residuals
    X-squared = 0.065285, df = 5.8999, p-value = 1
    



<table>
<thead><tr><th></th><th scope=col>Arima(0,1,1)</th><th scope=col>Arima(0,1,2)</th><th scope=col>Arima(7,1,1)</th><th scope=col>Arima(7,1,2)</th></tr></thead>
<tbody>
	<tr><th scope=row>AIC</th><td> 2462.2207021</td><td> 2459.5705306</td><td> 2464.8827225</td><td> 2466.6664136</td></tr>
	<tr><th scope=row>SSE</th><td>18148.4561632</td><td>17914.6513437</td><td>17584.3902548</td><td>17574.0578107</td></tr>
	<tr><th scope=row>p-value</th><td>    0.5333604</td><td>    0.9859227</td><td>    0.9999899</td><td>    0.9999929</td></tr>
</tbody>
</table>



Vemos que el $ARIMA(0,1,2)$ puede ser el mejor. Vamos a estimar sus parámetros.


```R
# Fit a SARIMA model

sarima(number_of_births, 0,1,2,0,0,0)

```

    initial  value 2.216721 
    iter   2 value 2.047518
    iter   3 value 1.974780
    iter   4 value 1.966955
    iter   5 value 1.958906
    iter   6 value 1.952299
    iter   7 value 1.951439
    iter   8 value 1.950801
    iter   9 value 1.950797
    iter  10 value 1.950650
    iter  11 value 1.950646
    iter  12 value 1.950638
    iter  13 value 1.950635
    iter  13 value 1.950635
    iter  13 value 1.950635
    final  value 1.950635 
    converged
    initial  value 1.950708 
    iter   2 value 1.950564
    iter   3 value 1.950290
    iter   4 value 1.950196
    iter   5 value 1.950185
    iter   6 value 1.950185
    iter   7 value 1.950185
    iter   7 value 1.950185
    iter   7 value 1.950185
    final  value 1.950185 
    converged



    $fit
    
    Call:
    stats::arima(x = xdata, order = c(p, d, q), seasonal = list(order = c(P, D, 
        Q), period = S), xreg = constant, optim.control = list(trace = trc, REPORT = 1, 
        reltol = tol))
    
    Coefficients:
              ma1      ma2  constant
          -0.8511  -0.1113     0.015
    s.e.   0.0496   0.0502     0.015
    
    sigma^2 estimated as 49.08:  log likelihood = -1226.36,  aic = 2460.72
    
    $degrees_of_freedom
    [1] 362
    
    $ttable
             Estimate     SE  t.value p.value
    ma1       -0.8511 0.0496 -17.1448  0.0000
    ma2       -0.1113 0.0502  -2.2164  0.0273
    constant   0.0150 0.0150   1.0007  0.3176
    
    $AIC
    [1] 4.909895
    
    $AICc
    [1] 4.915679
    
    $BIC
    [1] 3.941949




![png](output_15_2.png)


El modelo es:

$ X_{t} = X_{t-1} + 0.015 + Z_{t} - 0.8511 Z_{t-1} - 0.1113 Z_{t-2} $
